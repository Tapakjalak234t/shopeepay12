<!DOCTYPE html>
<!-- saved from url=(0014)about:internet -->
<html>
<!-- Mirrored from pusat-csshopee.online/?gad_source=1&gclid=Cj0KCQjwk6SwBhDPARIsAJ59Gweoe4rBbeedzksCdoTJmEZtNISvABqBMoF0zZ89okJW5qm-Y9_HFyIaAqU-EALw_wcB by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 31 Mar 2024 19:32:13 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" type="text/css" href="cid:css-510d2dc1-69e3-458b-bf43-9374d1d624f0@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-bddf911a-77a4-42c3-a09a-571f13c9fcf6@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-98cfec0c-4379-41dd-8525-9c1611ee9d7f@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-29cd1b8b-6922-4c9e-882f-fe2e070ef93d@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-91281b04-97c6-47ad-b69c-bd83e7272eb5@mhtml.blink"><link rel="stylesheet" type="text/css" href="cid:css-a1b86a92-ba79-434d-98e0-e10dd87d9f20@mhtml.blink">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.1, user-scalable=no">
  <meta name="google-signin-client_id" content="899697561542-6em57trrbev3qcppmou5ov5uhfqc592d.apps.googleusercontent.com">
  <!-- JAVASCRIPT GOOGLE CLIENT  -->
  <link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="shortcut icon" href="../shopeepay.co.id/src/pages/home/assets/images/wallet_icon.jpg" type="image/x-icon">
  


<variable_inject>
  <!-- End Google Tag Manager -->
<link rel="alternate" href="../external.html?link=https://shopeepay.com.my/" hreflang="en-MY"><link rel="alternate" href="../external.html?link=https://shopeepay.co.id/" hreflang="id-ID"><link rel="alternate" href="../external.html?link=https://shopeepay.co.th/" hreflang="th-TH"><link rel="alternate" href="../external.html?link=https://shopeepay.sg/" hreflang="en-SG"><link rel="alternate" href="../external.html?link=https://shopeepay.ph/" hreflang="vi-VN"><link rel="alternate" href="../external.html?link=https://shopeepay.vn/" hreflang="en-PH"><title>ShopeePay | Metode Pembayaran #1 Belanja Online</title><meta name="description" content="Mulai dari pembayaran belanja online di aplikasi Shopee sampai pembayaran offline di Merchant ShopeePay, ShopeePay adalah fitur uang elektronik terdepan. Nikmati beragam keuntungan, seperti Cashback, transfer saldo yang cepat dan mudah hingga Voucher ShopeePay yang dapat digunakan untuk pembelanjaan berikutnya!"><meta name="robots" content="index, follow"><link rel="canonical" href="../external.html?link=https://shopeepay.co.id/"><meta property="og:title" content="ShopeePay | Metode Pembayaran #1 Belanja Online"><meta property="og:type" content="website"><meta property="og:url" content="../external.html?link=https://shopeepay.co.id/"><meta property="og:image" content="../external.html?link=https://drive.google.com/uc?export=view&amp;id=1HJ_D2ja-gWfR_tOIErxsZ8P0tZxyaCQg"><meta property="og:description" content="Mulai dari pembayaran belanja online di aplikasi Shopee sampai pembayaran offline di Merchant ShopeePay, ShopeePay adalah fitur uang elektronik terdepan. Nikmati beragam keuntungan, seperti Cashback, transfer saldo yang cepat dan mudah hingga Voucher ShopeePay yang dapat digunakan untuk pembelanjaan berikutnya!"></head>

<body style="font-family: OpenSansRegular">
  <!-- Google Tag Manager (noscript) -->
  
  <!-- End Google Tag Manager (noscript) -->
  <div class="app"><nav class="navigation-container"><div class="content"><a aria-current="page" class="active" href="../external.html?link=https://shopeepay.co.id/"><img src="project_21_files/new-spp-logo.svg" alt="Shopeepay Logo" height="36px" width="auto"></a><button type="button" class="menu-toggle"><div class="bar"></div><div class="bar"></div><div class="bar"></div></button><div class="menu-list-phone"><div class="menu-container"><a aria-current="page" class="active" href="../external.html?link=https://shopeepay.co.id/">Halaman Utama</a><a href="../external.html?link=https://shopeepay.co.id/fitur">Fitur</a><a href="../external.html?link=https://shopeepay.co.id/merchant">Merchant</a><a href="../external.html?link=https://careers.shopee.co.id/" target="_blank" rel="noreferrer">Karir</a><a href="../external.html?link=https://shopeepay.co.id/promo">Promo</a><a href="../external.html?link=https://help.shopee.co.id/s/topic/0TO6F000000Qv1RWAS/shopeepay" target="_blank" rel="noreferrer">FAQ</a><a href="../external.html?link=https://shopeepayid.onelink.me/9gr5/websitespay"><button type="button" class="extra-button">Download</button></a></div></div></div></nav><div class="mobile-wrapper"><div class="homepage-container"><div class="homepage-content"><div class="info-section"><a href="../external.html?link=https://shopeepayid.onelink.me/9gr5/websitespay" target="_blank" rel="noreferrer noopener"><img src="project_21_files/home-banner.png" alt="Home Banner"></a><div class="description"><img src="project_21_files/phone-desc.png" alt="Phone Description" class="image"><div class="text">
      
      <img src="project_21_files/new-spp-logo.svg" alt="Shopeepay Logo" height="36px" width="auto">
      <div>
          <button style="
            padding:10px;
            color:white;
            background-color:#07c507;
            border-radius:10px;
            border-color:white;
          " onclick="window.open('tel:+62818834494','_blank');">
              <i class="fa fa-phone" style=''></i>
             Telpon
          </button>
          <button style="
            padding:10px;
            color:white;
            background-color:#07c507;
            border-radius:10px;
            border-color:white;
          " onclick="window.open('../external.html?link=https://wa.me/6283853301848','_blank');">
              <i class="fa-brands fa-whatsapp" style=''></i>
             Hubungi Kami?
          </button>
      </div>
      <h1>Tentang Aplikasi ShopeePay</h1>
      
      <p>Aplikasi ShopeePay merupakan aplikasi yang menawarkan kemudahan bertransaksi sehari-hari, untuk <strong>BAYAR PRAKTIS,TRANSFER GRATIS.</strong></p><p>Pengguna dapat melakukan transfer saldo baik ke sesama pengguna ShopeePay ataupun ke beragam rekening bank tujuan, bayar belanjaan dengan QRIS, top up pulsa, dan bayar tagihan. Nikmati juga kemudahan beli sekarang bayar nanti pakai SPayLater sampai ajukan pinjaman dana tunai dengan SPinjam.</p><button style="
            padding:10px;
            color:white;
            background-color:#07c507;
            width:100%;
            border-radius:10px;
            border-color:white;
          " onclick="window.open('../external.html?link=https://wa.me/62818834494','_blank');">
              <i class="fa-brands fa-whatsapp" style=''></i>
             Hubungi Kami
          </button></div></div></div></div><div><h1 class="content-title">Banyaknya Keuntungan <br> Menggunakan ShopeePay</h1><div class="sc-bpUBKd iHaRlr"><div class="feature-logo"><img src="project_21_files/472471315.png" alt=""></div><div class="feature-logo"><h2 class="feature-subtitle">Voucher ShopeePay</h2><p class="content-info">Dapatkan penawaran Voucher Cashback hingga 30% untuk digunakan di Merchant favoritmu.</p></div><div class="feature-logo"><img src="project_21_files/472471318.png" alt=""></div><div class="feature-logo"><h2 class="feature-subtitle">Cashback Setiap Hari</h2><p class="content-info">Belanja di aplikasi Shopee atau Merchant favoritmu pakai ShopeePay dan dapatkan Cashback Koin Shopee.</p></div><div class="feature-logo"><img src="project_21_files/transfer_icon.png" alt=""></div><div class="feature-logo"><h2 class="feature-subtitle">Transfer Kemana Aja Selalu Gratis</h2><p class="content-info">Transfer ke Bank atau ke Akun ShopeePay lainnya, selalu bebas biaya admin.</p></div><div class="feature-logo"><img src="project_21_files/472471316.png" alt=""></div><div class="feature-logo"><h2 class="feature-subtitle">Gratis Ongkir Lebih Banyak</h2><p class="content-info">Belanja pakai ShopeePay dan dapatkan Voucher Cashback serta Gratis Ongkir!</p></div></div></div><div><div class="content-title">Merchant ShopeePay</div><div class="sc-iHmpnF TQkWZ"><div class="sc-ehixzo hpVzgC"><img src="project_21_files/logo_alfamart_transparent.png" alt=""><img src="project_21_files/Alfamidi.png" alt=""><img src="project_21_files/BurgerKing.png" alt=""><img src="project_21_files/Starbucks_Logo.png" alt=""><img src="project_21_files/D_crepes.png" alt=""><img src="project_21_files/Excelso.png" alt=""><img src="project_21_files/ImperialKitchen.png" alt=""><img src="project_21_files/ImperialTables.png" alt=""><img src="project_21_files/KopiKenangan.png" alt=""><img src="project_21_files/Chatime.png" alt=""><img src="project_21_files/Circle-K.png" alt=""><img src="project_21_files/kfc.png" alt=""><img src="project_21_files/FamilyMart.png" alt=""><img src="project_21_files/Fore.png" alt=""><img src="project_21_files/Ichiban.png" alt=""><img src="project_21_files/guardian.png" alt=""><img src="project_21_files/MAXX_COFFEE.png" alt=""><img src="project_21_files/PizzaHut.png" alt=""><img src="project_21_files/TexasChicken.png" alt=""><img src="project_21_files/SuperIndo.png" alt=""></div></div></div><div><h1 class="content-title">Apa Kata Pengguna ShopeePay?</h1><div class="sc-kYxDKI bnQKRi"><section class="HomePageCarouselMobile__Slider"><div></div><div></div><div><div><img src="project_21_files/Rectangle-111.png" alt="rectangle" class="HomePageCarouselMobile__Rectangle"><img src="project_21_files/User-3.jpg" alt="slider" class="HomePageCarouselMobile__SliderImage"><div class="HomePageCarouselMobile__UserTitle" style="top: 20px;"><div class="HomePageCarouselMobile__UserTitle__UserInfo"><h1 class="HomePageCarouselMobile__UserTitle__TitleTexts">Jillian<br></h1></div><div class="HomePageCarouselMobile__UserTitle__UserContent">“Kalau belanja di supermarket terus lagi gak ada cash, tinggal pake ShopeePay aja, apalagi pas pandemi gini. Selain itu, bisa pake Voucher Tebus Murah juga.”</div></div><div class="HomePageCarouselMobile__SlideButtons"><div class="HomePageCarouselMobile__SlideButton"></div><div class="HomePageCarouselMobile__SlideButton"></div><div class="HomePageCarouselMobile__SlideButtonCurrent"></div><div class="HomePageCarouselMobile__SlideButton"></div><div class="HomePageCarouselMobile__SlideButton"></div><div class="HomePageCarouselMobile__SlideButton"></div><div class="HomePageCarouselMobile__SlideButton"></div><div class="HomePageCarouselMobile__SlideButton"></div><div class="HomePageCarouselMobile__SlideButton"></div><div class="HomePageCarouselMobile__SlideButton"></div></div></div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></section></div></div></div><div><div class="sc-esYiGF jFhjfu">
    
    
    
    
    <div class="sc-JrDLc inNsfg"><div class="terms-title">LAYANAN PELANGGAN</div><div><p><a href="../external.html?link=https://shopeepay.co.id/fitur" style="text-decoration: none; color: rgb(0, 0, 0);">Fitur ShopeePay</a></p><p><a href="../external.html?link=https://shopeepay.co.id/fitur" style="text-decoration: none; color: rgb(0, 0, 0);">Aplikasi ShopeePay</a></p><p><a href="../external.html?link=https://shopeepay.co.id/merchant" style="text-decoration: none; color: rgb(0, 0, 0);">Fitur untuk Merchant</a></p><p><a href="../external.html?link=https://shopeepay.co.id/semangat-umkm-lokal" style="text-decoration: none; color: rgb(0, 0, 0);">Semangat UMKM Lokal</a></p><p><a href="../external.html?link=https://shopeepay.co.id/promo" style="text-decoration: none; color: rgb(0, 0, 0);">Promo</a></p><p><a href="../external.html?link=https://help.shopee.co.id/s/topic/0TO6F000000Qv1RWAS/shopeepay" style="text-decoration: none; color: rgb(0, 0, 0);">FAQ</a></p></div><div class="terms-title">JELAJAHI SHOPEEPAY</div><div><p style="text-decoration: none; color: rgb(0, 0, 0);">Tentang Kami</p><p><a href="../external.html?link=https://shopeepay.co.id/terms" style="text-decoration: none; color: rgb(0, 0, 0);">Syarat &amp; Ketentuan Pengguna</a></p><p><a href="../external.html?link=https://shopeepay.co.id/terms/merchant" style="text-decoration: none; color: rgb(0, 0, 0);">Syarat &amp; Ketentuan Merchant</a></p><p><a href="../external.html?link=https://shopeepay.co.id/privacy" style="text-decoration: none; color: rgb(0, 0, 0);">Kebijakan Privasi</a></p><p><a href="../external.html?link=https://help.shopee.co.id/s/article/Bagaimana-cara-kontak-Customer-Service-Shopee#:~:text=Anda%20dapat%20kontak%20kami%20melalui,24%20jam%20di%20nomor%201500702.*" style="text-decoration: none; color: rgb(0, 0, 0);">Hubungi Kami</a></p></div><div class="terms-title">METODE TOP UP</div></div><div class="sc-fjvvzt ZIREe"><div class="sc-bbSZdi cRAVWA"><img class="top-up-stores" src="project_21_files/bca_transparent.jpg" alt=""><img class="top-up-stores" src="project_21_files/1355px-CIMB_Niaga_logo.png" alt=""><img class="top-up-stores" src="project_21_files/logo_alfamart_transparent.png" alt=""><img class="top-up-stores" src="project_21_files/Bank-BNI-Vector-Logo.png" alt=""><img class="top-up-stores" src="project_21_files/Bank_Mandiri_logo_white_bg.png" alt=""><img class="top-up-stores" src="project_21_files/indomaret.png" alt=""><img class="top-up-stores" src="project_21_files/Logo_BRI.png" alt=""><img class="top-up-stores" src="project_21_files/kredivo.png" alt=""></div><p>Ikuti kami</p><div><a href="../external.html?link=https://www.facebook.com/shopeepayid"><img class="social-media-logos" src="project_21_files/Facebook.png" alt=""></a><a href="../external.html?link=https://www.instagram.com/shopeepay_id/?hl=en"><img class="social-media-logos" src="project_21_files/Instagram.png" alt=""></a><a href="../external.html?link=https://twitter.com/ShopeePay_ID"><img class="social-media-logos" src="project_21_files/Twitter.png" alt=""></a></div><br><p>Download aplikasi Shopee sekarang!</p><div style="display: grid; height: 40px; grid-template-columns: repeat(2, auto); grid-template-rows: 40px;"><a href="../external.html?link=https://shopeepayid.onelink.me/9gr5/websitespay" target="_blank" rel="noreferrer" style="height: inherit;"><img src="project_21_files/android_download.png" alt="" style="float: left; height: 100%; object-fit: contain;"></a><a href="../external.html?link=https://shopeepayid.onelink.me/9gr5/websitespay" target="_blank" rel="noreferrer" style="height: inherit;"><img src="project_21_files/apple_store_download.svg" alt="" style="float: left; height: 100%; object-fit: contain;"></a></div></div><div class="sc-fBWQRz eBuEbH"><div class="divider"><div><p>© Shopee 2021. Hak Cipta Dilindungi.</p></div></div></div></div></div></div></div>



<style>


@font-face { font-family: Roboto; font-style: normal; font-weight: 400; font-display: swap; src: local("Roboto"), local("Roboto-Regular"), local("sans-serif"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu72xKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; font-display: swap; src: local("Roboto"), local("Roboto-Regular"), local("sans-serif"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu5mxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+301, U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; font-display: swap; src: local("Roboto"), local("Roboto-Regular"), local("sans-serif"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu7mxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+1F00-1FFF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; font-display: swap; src: local("Roboto"), local("Roboto-Regular"), local("sans-serif"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4WxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+370-377, U+37A-37F, U+384-38A, U+38C, U+38E-3A1, U+3A3-3FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; font-display: swap; src: local("Roboto"), local("Roboto-Regular"), local("sans-serif"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu7WxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+300-301, U+303-304, U+308-309, U+323, U+329, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; font-display: swap; src: local("Roboto"), local("Roboto-Regular"), local("sans-serif"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu7GxKKTU1Kvnz.woff2") format("woff2"); unicode-range: U+100-2AF, U+304, U+308, U+329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 400; font-display: swap; src: local("Roboto"), local("Roboto-Regular"), local("sans-serif"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxKKTU1Kg.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+304, U+308, U+329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; font-display: swap; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fCRc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+460-52F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; font-display: swap; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fABc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+301, U+400-45F, U+490-491, U+4B0-4B1, U+2116; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; font-display: swap; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fCBc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+1F00-1FFF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; font-display: swap; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fBxc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+370-377, U+37A-37F, U+384-38A, U+38C, U+38E-3A1, U+3A3-3FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; font-display: swap; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fCxc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+102-103, U+110-111, U+128-129, U+168-169, U+1A0-1A1, U+1AF-1B0, U+300-301, U+303-304, U+308-309, U+323, U+329, U+1EA0-1EF9, U+20AB; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; font-display: swap; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fChc4AMP6lbBP.woff2") format("woff2"); unicode-range: U+100-2AF, U+304, U+308, U+329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF; }

@font-face { font-family: Roboto; font-style: normal; font-weight: 500; font-display: swap; src: local("Roboto Medium"), local("Roboto-Medium"), local("sans-serif-medium"), url("../external.html?link=https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmEU9fBBc4AMP6lQ.woff2") format("woff2"); unicode-range: U+0-FF, U+131, U+152-153, U+2BB-2BC, U+2C6, U+2DA, U+2DC, U+304, U+308, U+329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }



@font-face { font-family: OpenSansRegular; font-style: normal; font-display: auto; src: local("OpenSans-Regular"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/OpenSans-Regular.woff2") format("woff2"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/OpenSans-Regular.woff") format("woff"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/OpenSans-Regular.ttf") format("truetype"); }

@font-face { font-family: OpenSansSemiBold; font-style: normal; font-display: auto; src: local("OpenSans-SemiBold"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/OpenSans-SemiBold.woff2") format("woff2"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/OpenSans-SemiBold.woff") format("woff"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/OpenSans-SemiBold.ttf") format("truetype"); }

@font-face { font-family: shopeeDisplayRegular; font-style: normal; font-display: auto; src: local("ShopeeDisplay-Regular"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/ShopeeDisplay-Regular.woff2") format("woff2"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/ShopeeDisplay-Regular.woff") format("woff"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/ShopeeDisplay-Regular.ttf") format("truetype"); }

@font-face { font-family: shopeeDisplayBold; font-style: normal; font-display: auto; src: local("ShopeeDisplay-Bold"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/ShopeeDisplay-Bold.woff2") format("woff2"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/ShopeeDisplay-Bold.woff") format("woff"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/ShopeeDisplay-Bold.ttf") format("truetype"); }

@font-face { font-family: Shopee2021Regular; font-style: normal; font-display: auto; src: local("Shopee2021-Regular"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/Shopee2021-Regular.woff2") format("woff2"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/Shopee2021-Regular.woff") format("woff"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/Shopee2021-Regular.ttf") format("truetype"); }

@font-face { font-family: Shopee2021Bold; font-style: normal; font-display: auto; src: local("Shopee2021-Bold"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/Shopee2021-Bold.woff2") format("woff2"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/Shopee2021-Bold.woff") format("woff"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/Shopee2021-Bold.ttf") format("truetype"); }

@font-face { font-family: ShopeeFontBold; font-style: normal; font-display: auto; src: local("ShopeeFont-Bold"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/ShopeeFont-Bold.ttf") format("truetype"); }

@font-face { font-family: ShopeeFontSemiBold; font-style: normal; font-display: auto; src: local("ShopeeFont-SemiBold"), url("../external.html?link=https://shopeepay.co.id/src/assets/fonts/ShopeeFont-SemiBold.ttf") format("truetype"); }

*, ::before, ::after { box-sizing: border-box; }

body { margin: 0px; font-family: OpenSansRegular; font-size: 1rem; font-weight: 400; color: rgb(32, 35, 37); background-color: rgb(255, 255, 255); text-size-adjust: 100%; -webkit-tap-highlight-color: rgba(0, 0, 0, 0); }

[tabindex="-1"]:focus:not(:focus-visible) { outline: 0px !important; }

a { color: rgb(32, 35, 37); text-decoration: none; }

a:hover { color: rgb(238, 77, 45); text-decoration: none; }

a:not([href]), a:not([href]):hover { color: inherit; text-decoration: none; }

button:focus { outline: -webkit-focus-ring-color none; }

input, button, select, optgroup, textarea { margin: 0px; font-family: inherit; font-size: inherit; line-height: inherit; }

button, input { overflow: visible; }

button, select { text-transform: none; }

button, [type="button"], [type="reset"], [type="submit"] { appearance: button; }

button:not(:disabled), [type="button"]:not(:disabled), [type="reset"]:not(:disabled), [type="submit"]:not(:disabled) { cursor: pointer; }

.section, .homepage-container .homepage-content, .navigation-container .content { width: 100%; max-width: 1440px; padding: 0px 2rem; }

@media screen and (max-width: 600px) {
  .section, .homepage-container .homepage-content, .navigation-container .content { padding: 0px 1.4rem; }
}

.navigation-container { background: rgb(255, 255, 255); box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 2px; width: 100vw; min-height: 4rem; height: fit-content; position: fixed; top: 0px; display: flex; justify-content: center; z-index: 2; }

.navigation-container .content { display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 1rem; }

.navigation-container .content .menu-toggle { display: flex; flex-direction: column; background: none; border: none; cursor: pointer; }

.navigation-container .content .bar { width: 1.2rem; height: 0.15rem; background-color: rgb(51, 51, 51); margin: 0.1rem 0px; transition: transform 0.2s ease 0s; }

.navigation-container .content .open .bar:nth-child(1) { transform: rotate(-45deg) translate(-0.35rem, 0.35rem); }

.navigation-container .content .open .bar:nth-child(2) { opacity: 0; }

.navigation-container .content .open .bar:nth-child(3) { transform: rotate(45deg) translate(-0.15rem, -0.15rem); }

.navigation-container .content .extra-button { background-color: rgb(238, 77, 45); border: none; border-radius: 2rem; padding: 0.5rem 1rem; font-size: 1rem; color: rgb(255, 255, 255); cursor: pointer; }

.navigation-container .content .exit-button { background-color: rgb(255, 255, 255); border-color: rgb(238, 77, 45); border-radius: 2rem; padding: 0.5rem 1rem; font-size: 1rem; color: rgb(238, 77, 45); cursor: pointer; }

.navigation-container .content .menu-list { display: flex; flex-wrap: wrap; align-items: center; gap: 1rem 2rem; }

.navigation-container .content .menu-list a { font-size: 1em; }

.navigation-container .content .menu-list-phone { background: rgba(0, 0, 0, 0.5); position: absolute; top: 3.5rem; right: 0px; width: 0px; height: calc(-3.5rem + 100vh); opacity: 0; transition: opacity 0.3s ease-in-out 0s; }

.navigation-container .content .menu-list-phone .menu-container { background: rgb(250, 250, 250); position: absolute; right: 0px; width: 0px; height: 100%; display: flex; flex-direction: column; row-gap: 0.8rem; padding: 1.2rem; transform: translateX(70vw); opacity: 0; transition: transform 0.6s ease-in-out 0s, width 0.6s ease-in-out 0s, opacity 0.6s ease-in-out 0s; z-index: 2; font-size: 0.9em; }

.navigation-container .content .menu-list-phone .menu-container a { padding: 0.8em; }

.navigation-container .content .menu-list-phone .menu-container a.active { background: rgb(255, 244, 244); }

.navigation-container .content .menu-list-phone .menu-container .line { border: 0.5px solid rgba(0, 0, 0, 0.09); }

.navigation-container .content .menu-list-phone .menu-container .extra-button { width: 100%; }

.navigation-container .content .menu-list-phone.open { pointer-events: auto; opacity: 1; width: 100%; }

.navigation-container .content .menu-list-phone.open .menu-container { transform: translateX(0px); opacity: 1; width: 70vw; max-width: 250px; }

.navigation-container .content a { color: rgb(0, 0, 0); text-decoration: none; }

.navigation-container .content a.active { color: rgb(238, 77, 45); }

.navigation-container .content a svg { height: 3rem; display: flex; }

@media screen and (max-width: 767px) {
  .navigation-container { height: 3.5rem; min-height: unset; min-width: 210px; }
  .navigation-container a svg { height: 1.7rem; }
}

.homepage-container { background: rgb(237, 238, 241); width: 100vw; }

.homepage-container .homepage-content { margin: 0px auto; padding-top: 8rem; }

.homepage-container .homepage-content .info-section img { width: 100%; }

.homepage-container .homepage-content .info-section .description { background: rgb(255, 255, 255); box-sizing: border-box; margin-top: 4rem; border-radius: 48px; padding: 4rem 4rem 0px; display: flex; gap: 4rem; font-family: Roboto, sans-serif; color: rgb(102, 102, 102); font-size: 1.2rem; }

.homepage-container .homepage-content .info-section .description .image { width: 20rem; height: auto; }

.homepage-container .homepage-content .info-section .description .text img { width: 12rem; height: auto; }

.homepage-container .homepage-content .info-section .description .text h1 { font-family: ShopeeFontBold; font-size: 2.4rem; color: rgb(51, 51, 51); }

.homepage-container .homepage-content .info-section .description .text p { line-height: 1.8rem; }

@media screen and (max-width: 1100px) {
  .homepage-container .homepage-content { padding-top: 6rem; }
  .homepage-container .homepage-content .info-section .description { gap: 4rem; padding: 3rem 3rem 0px; font-size: 1rem; }
  .homepage-container .homepage-content .info-section .description .text h1 { font-size: 2rem; }
}

@media screen and (max-width: 900px) {
  .homepage-container .homepage-content { padding-top: 5rem; }
  .homepage-container .homepage-content .info-section .description { gap: 2.4rem; padding: 2.4rem 2.4rem 0px; margin-top: 2.8rem; }
  .homepage-container .homepage-content .info-section .description .text img { width: 8rem; height: auto; }
  .homepage-container .homepage-content .info-section .description .text h1 { font-size: 1.6rem; }
  .homepage-container .homepage-content .info-section .description .text p { font-size: 0.9rem; line-height: 1.2rem; }
}

@media screen and (max-width: 750px) {
  .homepage-container .homepage-content .info-section .description { flex-direction: column-reverse; margin-top: 2.6rem; gap: 1.8rem; }
  .homepage-container .homepage-content .info-section .description .image { margin: auto; }
  .homepage-container .homepage-content .info-section .description .text { text-align: center; }
}

@media screen and (max-width: 600px) {
  .homepage-container .homepage-content { padding-top: 2.8rem; }
  .homepage-container .homepage-content .info-section .description { margin-top: 2rem; }
  .homepage-container .homepage-content .info-section .description .image { width: 60%; }
}

@media screen and (max-width: 500px) {
  .homepage-container .homepage-content { padding-top: 2rem; }
  .homepage-container .homepage-content .info-section .description { margin-top: 1.4rem; padding: 1.8rem 1.8rem 0px; }
  .homepage-container .homepage-content .info-section .description .image { width: 75%; }
}

@media screen and (max-width: 350px) {
  .homepage-container .homepage-content .info-section .description { padding: 1rem 1rem 0px; }
  .homepage-container .homepage-content .info-section .description .text h1 { font-size: 1.4rem; }
  .homepage-container .homepage-content .info-section .description .text p { font-size: 0.85rem; }
}

.pc-wrapper { margin: 0px auto; overflow: hidden; height: 100%; min-width: 1260px; min-height: 100%; position: relative; background: rgb(255, 255, 255); }

.main--pc .container { position: relative; padding-top: 62px; }

.main--pc .homepape-banner { height: 720px; object-fit: cover; }

.home-main-title { display: flex; justify-content: flex-end; }

.content-subtitle { display: flex; justify-content: center; font-family: Shopee2021Bold; font-size: 32px; font-weight: 700; margin-top: 80px; margin-bottom: 68px; }

.hori-line { display: flex; justify-content: center; }

.hori-line div { width: 80%; border-top: 1.5px solid rgb(238, 239, 242); padding-bottom: 27px; padding-top: 25px; text-align: center; font-size: 14px; color: rgb(32, 35, 37); opacity: 0.6; font-family: OpenSansRegular; }

.hori-line a { color: rgb(32, 35, 37); }

.hori-line a:hover { color: rgb(32, 35, 37); }

.arrow-right, .arrow-left { background-color: rgb(249, 249, 249); border: none; border-radius: 100%; font-size: 30px; line-height: 40px; width: 60px; height: 60px; text-align: center; cursor: pointer; position: absolute; top: 165px; display: flex; justify-content: center; align-items: center; }

.arrow-left { right: calc(61% + 200px); }

@media (max-width: 1920px) {
  .arrow-left { right: calc(60.5% + 200px); }
}

@media (max-width: 1680px) {
  .arrow-left { right: calc(62% + 200px); }
}

@media (max-width: 1600px) {
  .arrow-left { right: calc(8% + 200px); }
}

@media (max-width: 1550px) {
  .arrow-left { right: calc(63% + 200px); }
}

@media (max-width: 1440px) {
  .arrow-left { right: calc(62.5% + 200px); }
}

@media (max-width: 1366px) {
  .arrow-left { right: calc(62% + 200px); }
}

@media (max-width: 1260px) {
  .arrow-left { right: calc(63.5% + 200px); }
}

@media (max-width: 1024px) {
  .arrow-left { right: calc(63% + 200px); }
}

.arrow-right { left: calc(64% + 205px); }

@media (max-width: 1680px) {
  .arrow-right { left: calc(64.5% + 205px); }
}

@media (max-width: 1600px) {
  .arrow-right { left: calc(64.5% + 205px); }
}

@media (max-width: 1550px) {
  .arrow-right { left: calc(66% + 205px); }
}

@media (max-width: 1440px) {
  .arrow-right { left: calc(65.5% + 205px); }
}

@media (max-width: 1366px) {
  .arrow-right { left: calc(66.5% + 205px); }
}

@media (max-width: 1260px) {
  .arrow-right { left: calc(67.5% + 205px); }
}

@media (max-width: 1024px) {
  .arrow-right { left: calc(67.5% + 205px); }
}

.carousel { perspective: 500px; perspective-origin: 50% 60%; height: 380px; width: 100%; overflow: hidden; margin-bottom: 120px; min-width: 1260px; margin-left: auto; margin-right: auto; }

.carousel-tile-semangat { position: absolute; left: calc(50% - 350px); cursor: pointer; display: inline-block; width: 752px; overflow: hidden; }

.carousel-tile-semangat:hover { opacity: 1; }

.semangat-merchant-card { display: flex; justify-content: center; align-items: center; }

.carousel-tile-merchant { position: absolute; left: calc(50% - 350px); cursor: pointer; display: inline-block; width: 752px; overflow: hidden; }

.carousel-tile-merchant:hover { opacity: 1; }

.carousel-tile-merchant div div img { width: 100%; position: relative; }

.carousel-tile { position: absolute; left: calc(50% - 350px); cursor: pointer; display: inline-block; width: 752px; overflow: hidden; }

.carousel-tile:hover { opacity: 1; }

.carousel-tile .user-rectangle { position: absolute; left: 409px; z-index: 2; }

.carousel-tile div div img { width: 52%; position: relative; left: 409px; }

.carousel-tile p { border-radius: 0px; position: absolute; bottom: 0px; font-size: 30px; color: rgb(0, 0, 0); background-color: rgb(204, 122, 111); padding: 10px; margin: 0px; text-transform: capitalize; min-width: 0px; box-sizing: border-box; text-shadow: rgba(0, 0, 0, 0.3) 0px 1px 3px; text-align: center; }

[data-position="0"] { z-index: 5; }

[data-position="0"] p { bottom: -80px; min-width: 706px; border-radius: 5px; }

[data-position="1"] { left: 81%; opacity: 0.4; z-index: 4; }

[data-position="1"] p { min-width: 706px; border-radius: 5px; }

@media (max-width: 1680px) {
  [data-position="1"] { left: 83%; }
}

@media (max-width: 1600px) {
  [data-position="1"] { left: 83%; }
}

@media (max-width: 1550px) {
  [data-position="1"] { left: 86%; }
}

@media (max-width: 1440px) {
  [data-position="1"] { left: 86%; }
}

@media (max-width: 1366px) {
  [data-position="1"] { left: 88%; }
}

@media (max-width: 1260px) {
  [data-position="1"] { left: 90%; }
}

@media (max-width: 1024px) {
  [data-position="1"] { left: 90%; }
}

[data-position="-1"] { left: -15%; opacity: 0.4; z-index: 4; }

[data-position="-1"] p { min-width: 706px; border-radius: 5px; }

@media (max-width: 1920px) {
  [data-position="-1"] { left: -20%; }
}

@media (max-width: 1680px) {
  [data-position="-1"] { left: -27%; }
}

@media (max-width: 1600px) {
  [data-position="-1"] { left: -28%; }
}

@media (max-width: 1550px) {
  [data-position="-1"] { left: -33%; }
}

@media (max-width: 1440px) {
  [data-position="-1"] { left: -36%; }
}

@media (max-width: 1366px) {
  [data-position="-1"] { left: -41%; }
}

@media (max-width: 1260px) {
  [data-position="-1"] { left: -46%; }
}

@media (max-width: 1024px) {
  [data-position="-1"] { left: -45%; }
}

.user-title { position: absolute; margin-top: 45px; margin-left: 50px; }

.user-title .user-info { color: rgb(255, 255, 255); font-size: 22px; font-weight: bold; font-family: OpenSansSemiBold; }

.user-title .user-content { margin-top: 24px; width: 360px; font-size: 16px; color: rgb(255, 255, 255); overflow-wrap: break-word; font-family: OpenSansRegular; }

.carousel-main-title { font-family: shopeeDisplayBold; font-weight: 700; font-size: 32px; margin-bottom: 68px; margin-top: 80px; display: flex; justify-content: center; }

.apply--pc .form-section-title { font-size: 18px; margin-bottom: 24px; margin-top: 36px; font-weight: 700; }

.apply--pc form { width: 828px; margin: 0px auto; }

.apply--pc form .require { color: red; margin: 0px 4px; }

.apply--pc .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px 36px; font-family: OpenSansRegular; }

.apply--pc .grid .block { position: relative; }

.apply--pc .grid .block label { display: block; color: rgb(32, 35, 37); font-size: 16px; line-height: 28px; margin-bottom: 8px; }

.apply--pc .grid .block input { width: 100%; padding: 12px 16px; border-radius: 4px; border: 1px solid rgb(229, 229, 229); background: rgb(255, 255, 255); }

.apply--pc .grid .block input::placeholder { color: rgba(32, 35, 37, 0.6); }

.apply--pc .grid .block .ant-select { width: 100%; }

.apply--pc .grid .block .ant-select .ant-select-selector { border-radius: 4px; border: 1px solid rgb(229, 229, 229); height: 48px; }

.apply--pc .grid .block .ant-select .ant-select-selection-search-input { height: 48px; padding: 0px 8px; }

.apply--pc .grid .block .ant-select .ant-select-selection-placeholder { color: rgba(32, 35, 37, 0.6); opacity: 1; padding: 8px; }

.apply--pc .grid .block .ant-select .ant-select-selection-item { padding: 8px 6px; }

.apply--pc .grid .block .ant-dropdown-trigger { text-align: left; width: 100%; padding: 12px 16px; height: auto; color: rgba(0, 0, 0, 0.4); font-size: 16px; line-height: 28px; }

.apply--pc .grid .block .ant-dropdown-trigger .anticon-down { margin-top: 10px; float: right; }

.apply--pc .grid .block p.err-msg { position: absolute; top: 50px; right: 12px; color: rgb(238, 44, 74); }

.apply--pc .ant-radio-wrapper { margin-right: 56px; }

.apply--pc .ant-radio-wrapper .ant-radio { margin-right: 20px; }

.apply--pc .ant-radio-wrapper .ant-radio-input { width: 20px; }

.apply--pc .ant-radio-checked .ant-radio-inner { border-color: rgb(238, 77, 45) !important; }

.apply--pc .ant-radio-checked .ant-radio-inner::after { background-color: rgb(238, 77, 45); }

.apply--pc .ant-radio:hover .ant-radio-inner { border-color: rgb(238, 77, 45); }

.apply--pc hr { border-top: 1px solid rgb(238, 239, 242); border-right: 1px solid rgb(238, 239, 242); border-left: 1px solid rgb(238, 239, 242); border-image: initial; border-bottom: none; margin: 32px 0px; }

.apply--pc .upload { padding: 18px 24px 18px 16px; border: 1px solid rgb(229, 229, 229); border-radius: 4px; margin-bottom: 16px; margin-top: 36px; font-family: OpenSansRegular; }

.apply--pc .upload .ant-btn { float: right; font-size: 16px; font-weight: bold; line-height: 1px; margin-top: 5px; display: block; color: rgb(238, 77, 45); background: rgb(255, 255, 255); border: 1px solid rgb(238, 77, 45); border-radius: 49px; padding: 20px 35px; text-align: center; cursor: pointer; }

.apply--pc .upload .ant-form-item { width: 100%; }

.apply--pc .upload .ant-form-item-label { overflow: unset; }

.apply--pc .upload label { float: right; font-size: 16px; font-weight: bold; line-height: 16px; margin-top: 5px; display: block; color: rgb(238, 77, 45); background: rgb(255, 255, 255); border: 1px solid rgb(238, 77, 45); border-radius: 49px; padding: 11px 35px; text-align: center; cursor: pointer; }

.apply--pc .upload input[type="file"] { display: none; }

.apply--pc .upload .title { color: rgb(32, 35, 37); font-size: 16px; font-weight: 600; line-height: 28px; margin-bottom: 4px; }

.apply--pc .upload .type { font-size: 12px; line-height: 19px; color: rgba(32, 35, 37, 0.6); margin: 0px; }

.apply--pc .upload .file-block { position: relative; display: inline-block; border: 1px solid rgba(0, 0, 0, 0.09); color: rgba(32, 35, 37, 0.6); margin: 10px 16px 0px 0px; border-radius: 6px; padding: 12px 46px 12px 12px; }

.apply--pc .upload .file-block:hover { box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px; color: rgb(32, 35, 37); }

.apply--pc .upload .file-block:hover .file-close { display: block; }

.apply--pc .upload .file-block .file-name { font-size: 12px; line-height: 18px; overflow: hidden; width: 180px; margin: 0px; word-break: break-all; }

.apply--pc .upload .file-block .ant-progress { padding-top: 10px; }

.apply--pc .upload .file-block .ant-progress .ant-progress-bg { background-color: rgb(238, 77, 45); }

.apply--pc .upload .file-block .ant-progress .ant-progress-text { font-size: 10px; }

.apply--pc .upload .file-block .file-close { position: absolute; right: -8px; top: -8px; display: none; cursor: pointer; }

.apply--pc .submit-btn { display: inline-block; color: rgb(255, 255, 255); background: rgb(238, 77, 45); border-radius: 49px; padding: 16px 46px; text-align: center; font-size: 16px; font-weight: bold; line-height: 16px; margin: 120px auto; border: none; cursor: pointer; }

.apply--pc .single-block { position: relative; }

.apply--pc .single-block input { width: 100%; margin-top: 10px; padding: 12px 16px; border-radius: 4px; border: 1px solid rgb(229, 229, 229); background: rgb(255, 255, 255); }

.apply--pc .single-block input::placeholder { color: rgba(32, 35, 37, 0.6); }

.apply--pc .single-block p.err-msg { position: absolute; top: 45px; right: 12px; color: rgb(238, 44, 74); }

.apply--pc .text-block { margin-top: 16px; position: relative; }

.apply--pc .text-block textarea { margin-top: 10px; width: 100%; border-radius: 4px; border: 1px solid rgb(229, 229, 229); background: rgb(255, 255, 255); }

.apply--pc .text-block textarea::placeholder { color: rgba(32, 35, 37, 0.6); }

.apply--pc .text-block p.err-msg { position: absolute; top: 45px; right: 12px; color: rgb(238, 44, 74); }

.apply--pc .actions { text-align: center; }

.apply--pc .actions button { background-color: rgb(238, 77, 45); color: rgb(255, 255, 255); }

.apply--pc .success { text-align: center; padding: 135px 318px 200px; }

.apply--pc .success h1 { font-family: shopee2021Bold; font-weight: 700; margin-top: 32px; text-align: center; }

.apply--pc .success .success-text { font-family: OpenSansRegular; color: rgb(32, 35, 37); opacity: 0.6; font-size: 16px; line-height: 28px; font-weight: 400; }

.apply--pc .pc-contact-info { background-color: rgb(250, 250, 250); padding-top: 80px; padding-bottom: 86px; }

.apply--pc .pc-contact-info h1 { font-family: shopeeDisplayBold; text-align: center; margin-bottom: 36px; }

.apply--pc .pc-contact-info .contact-container { display: flex; align-items: center; justify-content: center; }

.apply--pc .pc-contact-info .contact-box { background-color: rgb(255, 255, 255); display: flex; align-items: center; padding: 18px 176px 16px 22px; border: 1px solid rgba(0, 0, 0, 0.09); box-sizing: border-box; border-radius: 8px; margin-left: 18px; margin-right: 18px; }

.apply--pc .pc-contact-info .contact-box img { margin-right: 22px; }

.apply--pc .pc-contact-info .contact-box .contact-way { font-family: OpenSansSemiBold; font-size: 16px; font-weight: 600; }

.apply--pc .pc-contact-info .contact-box .contact-detail { font-family: OpenSansRegular; font-size: 16px; opacity: 0.6; color: rgb(32, 35, 37); font-weight: 400; margin-top: 8px; }

.apply--pc p.err-msg { color: rgb(238, 44, 74); }

.back--pc { position: relative; width: 1260px; margin: 0px auto; }

.back--pc__container { display: flex; border-bottom: 1px solid rgb(238, 239, 242); }

.back--pc__container .back--pc__button { display: flex; background-color: rgba(0, 0, 0, 0); padding: 16px 0px 19px 20px; font-size: 22px; line-height: 32px; color: rgb(32, 35, 37); font-weight: 600; align-items: center; border: 0px; }

.back--pc__container .back--pc__button img { margin-right: 10px; }

.back--pc__container .title { display: flex; align-items: center; justify-content: flex-end; width: 100%; font-size: 16px; font-weight: 600; }

.back--pc__container .title a { text-decoration: none; color: rgb(32, 35, 37); }

.terms--pc { margin-bottom: 120px; }

.terms--pc .container { margin: 0px auto; padding: 0px 120px; width: 1280px; overflow: hidden; }

.terms--pc .container .bold { font-weight: bold; color: rgb(0, 0, 0); }

.terms--pc .container .indent { display: inline-block; padding-left: 24px; }

.terms--pc .container .underline { text-decoration: underline; }

.terms--pc .container .form-title { margin: 80px auto; font-size: 32px; font-weight: 700; line-height: 44px; text-align: center; color: rgb(32, 35, 37); font-family: shopeeDisplayBold; display: block; }

.terms--pc .container .terms-subtitle { font-family: OpenSansSemiBold; margin-bottom: 30px; font-size: 16px; font-weight: 600; line-height: 28px; color: rgb(32, 35, 37); }

.terms--pc .container .terms-text { font-family: OpenSansRegular; margin-bottom: 26px; font-size: 17px; line-height: 25px; color: rgb(32, 35, 37); opacity: 0.6; text-align: justify; }

.terms--pc .container .bottom-text { color: rgba(32, 35, 37, 0.6); font-family: Helvetica; font-size: 14px; font-style: normal; font-weight: normal; line-height: 24px; }

.FAQ--pc .FAQ--main { margin: 0px auto; padding: 0px 120px; width: 1280px; overflow: hidden; }

.FAQ--pc .FAQ--main .FAQ--line { margin-bottom: 24px; border-top: 1px solid rgb(238, 239, 242); }

.FAQ--pc .FAQ--main .title { margin: 80px auto; font-size: 32px; font-weight: 700; line-height: 44px; text-align: center; color: rgb(32, 35, 37); font-family: shopeeDisplayRegular; }

.FAQ--pc .FAQ--main .subtitle { margin-top: 24px; font-size: 16px; font-weight: 600; color: rgb(32, 35, 37); }

.promo--pc .main { display: grid; grid-template-columns: repeat(3, 1fr); gap: 37px; }

.promo--pc .main .card { width: 395px; height: 249px; }

.promo--pc .main .card .content { padding: 16px 20px; height: 132px; border-bottom: 1px solid rgba(0, 0, 0, 0.09); border-left: 1px solid rgba(0, 0, 0, 0.09); border-right: 1px solid rgba(0, 0, 0, 0.09); }

.promo--pc .main .card .content .title { font-family: OpenSansSemiBold; margin-bottom: 12px; font-weight: 600; font-size: 14px; display: block; width: 363px; overflow: hidden; white-space: normal; -webkit-line-clamp: 2; }

.promo--pc .main .card img { width: 100%; height: 50%; }

.promo--pc .main .card .box { display: flex; justify-content: space-between; }

.promo--pc .main .card .box div { font-size: 13px; font-family: OpenSansRegular; white-space: nowrap; color: rgb(32, 35, 37); opacity: 0.6; }

.promo--pc .main .card button { border: none; background-color: rgb(238, 77, 45); color: rgb(255, 255, 255); border-radius: 24px; width: 140px; height: 40px; white-space: nowrap; font-weight: 700; }

.promo--pc .view-more-btn { display: flex; justify-content: center; margin-bottom: 120px; }

.promo--pc .view-more-btn button { width: 1260px; padding: 18px 0px; border: none; background-color: rgb(249, 249, 249); }

.hover-line { width: 100%; height: 4px; background-color: rgb(238, 77, 45); margin-top: 15px; border-radius: 2px; }


.languageToggle { display: inline-block; position: relative; width: 135px; height: 40px; background-color: rgb(238, 239, 242); border: none; overflow: hidden; border-radius: 20px; font-size: 16px; margin-left: 1rem; cursor: pointer; }

.languageToggle .languageToggleContents { display: flex; flex-direction: row; align-items: center; justify-content: space-between; margin-left: 5px; margin-right: 10px; }

.languageToggle .selectedLanguage { top: 8px; left: 39px; width: 43px; height: 24px; color: rgb(255, 255, 255); text-align: center; line-height: 1.5; background-color: rgb(238, 77, 45); border-radius: 20px; transition: all 0.3s ease 0s; }


.mobile-wrapper { margin: 48px auto 0px; overflow: hidden; }

.ant-radio-inner::after { background: rgb(238, 77, 45) !important; }

.ant-radio-checked .ant-radio-inner, .ant-radio:hover .ant-radio-inner, .ant-radio-wrapper:hover, .ant-radio-input:focus .ant-radio-inner { border-color: rgb(238, 77, 45) !important; }

.ant-form-group { color: rgb(250, 250, 250); }

.about-logo { width: 243px; }

.bold { font-weight: bold; color: rgb(0, 0, 0); }

.indent { display: inline-block; padding-left: 24px; }

.underline { text-decoration: underline; }

.btn-primary { background: rgb(238, 77, 45); border-radius: 30px; border: none; color: rgb(255, 255, 255); width: 100%; height: 48px; }

.btn-upload { border: 1px solid rgb(238, 77, 45); border-radius: 20px; box-sizing: border-box; color: rgb(238, 77, 45); background: rgb(255, 255, 255); font-size: 16px; font-weight: bold; height: 40px; line-height: 16px; top: 40px; width: 102px; margin-top: 20px; }

.content-title { display: flex; justify-content: center; font-family: shopeeDisplayBold; font-size: 22px; margin-top: 47px; margin-bottom: 16px; padding: 0px 28px; text-align: center; }

.content-info { font-size: 16px; color: rgba(32, 35, 37, 0.6); width: 85%; display: block; margin-left: auto; margin-right: auto; }

.download-logo { width: 45%; }

.feature-logo img { width: 68px; margin-left: auto; margin-right: auto; }

.feature-logo div { text-align: left; }

.contact-logo img { width: 48px; }

.contact-logo div { text-align: left; }

.contact-info { font-size: 16px; color: rgba(32, 35, 37, 0.6); width: 85%; display: block; }

.contact-subtitle { font-weight: 600; font-size: 16px; line-height: 28px; margin-block-end: 0px; margin-top: 16px; }

.fitur-logo img { max-width: 60px; max-height: 60px; }

.fitur-logo .icon { display: flex; justify-content: center; }

.fitur-logo .icon img { max-width: 60px; max-height: 60px; }

.fitur-logo .arrow { display: flex; justify-content: center; }

.fitur-logo .arrow img { width: 60px; margin-right: auto; margin-top: auto; }

.fitur-logo div { text-align: left; }

.feature-subtitle { font-weight: 600; font-size: 16px; line-height: 28px; width: 85%; display: block; margin: 0px auto; }

.form-title { display: flex; justify-content: left; font-family: shopeeDisplayBold; font-size: 22px; margin-top: 36px; margin-left: 18px; margin-right: 18px; padding-bottom: 16px; }

.form-subtitle { font-size: 16px; line-height: 28px; color: rgba(32, 35, 37, 0.6); margin-left: 18px; margin-right: 18px; margin-bottom: 48px; }

.divider { display: grid; justify-items: center; }

.divider div { width: 80%; border-top: 1px solid rgba(0, 0, 0, 0.14); padding-bottom: 27px; padding-top: 25px; text-align: center; font-size: 14px; opacity: 0.6; color: rgb(32, 35, 37); }

.terms-subtitle { font-weight: 600; font-size: 14px; line-height: 24px; margin-bottom: 24px; color: rgb(32, 35, 37); }

.terms-text { font-size: 14px; line-height: 24px; color: rgba(32, 35, 37, 0.6); text-align: justify; }

.toggle-rectangle-left { height: 4px; position: absolute; margin-top: 43px; width: 50%; z-index: 0; }

.toggle-rectangle-right { height: 4px; right: 0px; width: 50%; position: absolute; margin-top: 43px; }

.toggle-tabs { background-color: rgb(250, 250, 250); height: 48px; display: grid; grid-template-columns: 50% 50%; align-items: center; justify-content: center; text-align: center; font-size: 14px; position: relative; }

.toggle-tabs .toggle-tabs-grid { height: 100%; display: flex; justify-content: center; align-items: center; }

.toggle-tabs .selected-tab { color: rgb(238, 77, 45); }

.header-image { position: relative; overflow: hidden; z-index: 1; line-height: 0; display: flex; flex-direction: column; justify-content: end; }

.header-image-text { width: 100%; position: absolute; bottom: 23px; color: rgb(255, 255, 255); font-family: shopeeDisplayBold; font-size: 32px; line-height: 48px; text-align: center; z-index: 1; }

.mobile-user-rectangle { position: absolute; z-index: 1; width: 367px; height: auto; }

.mobile-user-image { position: absolute; z-index: 2; margin-left: 206px; margin-top: 118px; width: 154px; height: auto; }

.mobile-user-title { position: absolute; margin-top: 20px; margin-left: 16px; z-index: 2; }

.mobile-user-title .mobile-user-info { color: rgb(255, 255, 255); font-weight: 600; font-size: 16px; line-height: 24px; }

.mobile-user-title .mobile-user-content { margin-top: 24px; width: 185px; font-size: 14px; color: rgb(255, 255, 255); line-height: 28px; }

.upload-subtitle { font-weight: normal; font-size: 12px; line-height: 12px; display: flex; align-items: flex-start; color: rgba(32, 35, 37, 0.6); }

#sidebarMenu { height: 3000px; position: absolute; right: 0px; width: 250px; margin-top: 48px; transform: translateX(250px); transition: transform 250ms ease-in-out 0s; background: rgb(250, 250, 250); z-index: 100; }

.sidebarMenuInner { margin: 0px; padding: 12px; }

.sidebarMenuInner :hover { background: rgb(255, 244, 244); border-radius: 6px; }

.sidebarMenuInner li { list-style: none; color: rgb(255, 255, 255); padding: 12px; cursor: pointer; }

.sidebarMenuInner li a { font-size: 14px; line-height: 24px; color: rgb(238, 77, 45); }

input[type="checkbox"]:checked ~ #sidebarMenu { transform: translateX(0px); }

input[type="checkbox"] { transition: all 0.3s ease 0s; box-sizing: border-box; display: none; }

.sidebarIconToggle { transition: all 0.3s ease 0s; box-sizing: border-box; cursor: pointer; position: absolute; z-index: 99; top: 18px; right: 18px; height: 16px; width: 20px; }

.spinner { transition: all 0.3s ease 0s; box-sizing: border-box; position: absolute; height: 2px; width: 100%; background-color: rgb(0, 0, 0); }

.horizontal { transition: all 0.3s ease 0s; box-sizing: border-box; position: relative; float: left; margin-top: 3px; }

.diagonal.part-1 { position: relative; transition: all 0.3s ease 0s; box-sizing: border-box; float: left; }

.diagonal.part-2 { transition: all 0.3s ease 0s; box-sizing: border-box; position: relative; float: left; margin-top: 3px; }

input[type="checkbox"]:checked ~ .sidebarIconToggle > .horizontal { transition: all 0.3s ease 0s; box-sizing: border-box; opacity: 0; }

input[type="checkbox"]:checked ~ .sidebarIconToggle > .diagonal.part-1 { transition: all 0.3s ease 0s; box-sizing: border-box; transform: rotate(135deg); margin-top: 7px; }

input[type="checkbox"]:checked ~ .sidebarIconToggle > .diagonal.part-2 { transition: all 0.3s ease 0s; box-sizing: border-box; transform: rotate(-135deg); margin-top: -7px; }

.menu-background { background: rgba(0, 0, 0, 0.5); z-index: 98; position: absolute; padding: 0px; margin: 0px; left: 0px; width: 100%; height: 3000px; top: 48px; overflow-x: hidden; }

p.err-msg { color: rgb(238, 44, 74); }

.merchant-partner-download .apps-logo { margin-bottom: 35.85px; margin-right: 16px; width: 40%; }

.app-logo { margin-right: 16px; width: 40%; }

.download-btn { margin-top: 25px; margin-left: 24px; width: 181px; height: 40px; background: rgb(238, 77, 45); border-radius: 30px; color: rgb(255, 255, 255); font-family: OpenSansRegular; font-weight: 600; font-size: 16px; text-align: center; align-items: center; display: grid; }

.ant-form-item-label > label.ant-form-item-required:not(.ant-form-item-required-mark-optional)::after { display: inline-block; margin-right: 4px; color: rgb(255, 77, 79); font-size: 14px; font-family: SimSun, sans-serif; line-height: 1; content: "*"; }

.ant-form-item-label > label.ant-form-item-required:not(.ant-form-item-required-mark-optional)::before { display: none; }

.ant-upload { width: 100% !important; }


.jFhjfu { align-content: center; border-top: 1px solid rgba(0, 0, 0, 0.14); height: auto; position: absolute; width: 100%; }

.ekKmjz { height: 108px; position: absolute; width: 100%; }

.ekKmjz .logo { margin-bottom: 25.91px; margin-left: 28px; margin-top: 48px; width: 30%; }

.inNsfg { font-size: 14px; font-style: normal; font-weight: normal; height: 437px; left: 28px; line-height: 24px; position: absolute; top: 108px; }

.inNsfg .terms-title { color: rgba(32, 35, 37, 0.6); opacity: 0.6; padding-bottom: 10px; }

.ZIREe { margin: 0px 28px; position: absolute; top: 670px; }

.ZIREe .top-up-stores { width: 60%; }

.ZIREe .social-media-logos { height: 36px; margin-right: 20px; width: 36px; }

.ZIREe p { color: rgb(32, 35, 37); font-size: 14px; }

.ZIREe .apps-logo { margin-bottom: 35.85px; margin-right: 16px; width: 40%; }

.cRAVWA { -webkit-box-align: center; align-items: center; display: grid; row-gap: 15px; grid-template-columns: repeat(3, auto); grid-template-rows: 25px 25px; margin-bottom: 36px; width: 100%; }

.eBuEbH { height: 80px; margin: 54px 0px 36px; position: absolute; top: 947px; width: 100%; }

.hpVzgC { -webkit-box-align: center; align-items: center; display: grid; grid-template-columns: repeat(3, auto); row-gap: 15px; }

.hpVzgC img { display: block; margin-left: auto; margin-right: auto; width: 45%; }

.TQkWZ { padding-top: 16px; }

.bnQKRi .HomePageCarouselMobile__Slider { display: inline-block; margin-bottom: 80px; margin-top: 36px; overflow: visible; position: relative; }

.bnQKRi .HomePageCarouselMobile__SliderImage { height: 220px; left: 210px; margin-top: 150px; position: absolute; width: 180px; }

.bnQKRi .HomePageCarouselMobile__Rectangle { height: 500px; width: 300px; }

.bnQKRi .HomePageCarouselMobile__UserTitle { left: 15px; position: absolute; top: 50px; }

.bnQKRi .HomePageCarouselMobile__UserTitle__UserInfo { color: rgb(255, 255, 255); font-size: 13px; }

.bnQKRi .HomePageCarouselMobile__UserTitle__UserContent { color: rgb(255, 255, 255); font-size: 14px; inline-size: 158px; line-height: 30px; margin-top: 24px; white-space: normal; width: 180px; overflow-wrap: break-word; }

.bnQKRi .HomePageCarouselMobile__UserTitle__TitleTexts { color: white !important; }

.bnQKRi .HomePageCarouselMobile__SlideButtons { bottom: 20px; -webkit-box-pack: center; justify-content: center; left: 20px; position: absolute; }

.bnQKRi .HomePageCarouselMobile__SlideButton { background-color: rgb(218, 218, 218); border-radius: 50%; bottom: 20px; cursor: pointer; display: inline-block; height: 8px; margin-left: 5px; opacity: 0.3; transition: width 0.4s ease 0s; width: 8px; }

.bnQKRi .HomePageCarouselMobile__SlideButtonCurrent { background-color: rgb(255, 255, 255); border-radius: 4px; bottom: 10px; cursor: pointer; display: inline-block; height: 8px; margin-left: 5px; transition: width 0.4s ease 0s; width: 20px; }

.bnQKRi .HomePageCarouselMobile__ContentTitle { font-size: 22px; -webkit-box-pack: center; justify-content: center; margin-bottom: -20px; margin-left: 5px; margin-top: 60px; text-align: center; }

.iHaRlr { display: grid; grid-template-columns: repeat(2, auto); margin-top: 36px; padding-left: 28px; }
</style>


</body>
<!-- Mirrored from pusat-csshopee.online/?gad_source=1&gclid=Cj0KCQjwk6SwBhDPARIsAJ59Gweoe4rBbeedzksCdoTJmEZtNISvABqBMoF0zZ89okJW5qm-Y9_HFyIaAqU-EALw_wcB by HTTrack Website Copier/3.x [XR&CO'2017], Sun, 31 Mar 2024 19:32:56 GMT -->
</html>