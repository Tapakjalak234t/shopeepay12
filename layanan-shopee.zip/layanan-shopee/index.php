<?php
header('Location: home');
?>

